# OSHA Nightmare — Industrial Typography Kit

A Vite-compatible CSS treatment for HTML menu overlays on top of Three.js.

## Install

Copy `osha-ui.css` and the `assets/` folder into your Vite `src/ui/` directory (keep relative paths unchanged). Import CSS into `main.js` or another entry point:

```js
import './ui/osha-ui.css';
```

Alternatively, keep them in `public/ui/` and include `<link rel="stylesheet" href="/ui/osha-ui.css">` in index.html.

## Use

```html
<h1 class="osha-text osha-text--yellow" data-text="OSHA">OSHA</h1>
<h2 class="osha-text osha-text--ivory" data-text="NIGHTMARE">NIGHTMARE</h2>
<button class="osha-plate osha-button">
  <span class="osha-text osha-text--yellow osha-text--small" data-text="RESUME">RESUME</span>
</button>
```

For dynamic labels, update both `textContent` and `dataset.text`:

```js
const setOshaText = (element, value) => {
  element.textContent = value;
  element.dataset.text = value;
};
```

## Styling

Change CSS variables `--osha-yellow`, `--osha-ivory`, `--osha-red` globally or customize `--osha-ink` per element. Use `osha-text--small`, `osha-text--medium`, or omit modifier for large type. Distress is procedurally generated in `assets/heavy-distress-mask.svg` and applied to the letter faces. Because browser text cannot reproduce individually modeled 3D logo characters, this is a *coordinated aesthetic*, not a pixel-exact replica of the generated logo.

## Font and license

The base font is **Black Ops One** (OFL 1.1), loaded from Google Fonts online; the ZIP intentionally does not redistribute any font binaries. It can be used commercially under the license terms. To ship offline, self-host a licensed font you download yourself and change the `@import` to a local `@font-face` rule.

## Browser support

Modern Chrome / Firefox / Safari; Chrome is the suggested target. Demo `index.html` can be opened through your Vite dev server. Overlay CSS affects DOM text, not WebGL text meshes.
